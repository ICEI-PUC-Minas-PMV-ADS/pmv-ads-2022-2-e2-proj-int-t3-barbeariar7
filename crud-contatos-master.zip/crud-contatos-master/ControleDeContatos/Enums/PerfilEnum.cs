﻿namespace ControleDeContatos.Enums
{
    public enum PerfilEnum
    {
        Admin = 1,
        Padrao = 2
    }
}
