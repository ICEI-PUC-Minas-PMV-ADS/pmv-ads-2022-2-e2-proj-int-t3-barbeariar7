﻿using BarbeariaR7.Models;
using Microsoft.EntityFrameworkCore;
namespace BarbeariaR7.Data
{
    public class BancoContext: DbContext
    {
        public BancoContext() 
        {

        }
        public BancoContext(DbContextOptions<BancoContext> options) : base(options)
        {

        }

        public DbSet<CadastroModel> Cadastros { get; set; }
    }
}
