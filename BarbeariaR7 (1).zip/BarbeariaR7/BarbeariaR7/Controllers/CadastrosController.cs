﻿using Microsoft.AspNetCore.Mvc;

namespace BarbeariaR7.Controllers
{
    public class CadastrosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
